package toy;

public class Doll extends FigureTypeToy{

    public Doll() {
        super(3);
    }

    public String toString() {
        return super.toString()
                +"]";
    }
}

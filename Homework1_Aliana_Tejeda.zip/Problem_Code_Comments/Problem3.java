public class Problem3 {
	public static void main(String[] args) {
		int i = 5 / 0;
	}
}

//cannot devide by zero with integers, will get exception error

public class Problem9 {
	public static void main(String[] args) {
		float sum = 0.0;
	}
}
// to signify a float is mught be 0.0f, that is a double which is an incompatible type
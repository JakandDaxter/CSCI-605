public class Problem7 {
	public static void main(String[] args) {
		char ch = "a";
	}
}
//need to case the string "a" into a char before trying to input it into a object which is a char. incompatible types
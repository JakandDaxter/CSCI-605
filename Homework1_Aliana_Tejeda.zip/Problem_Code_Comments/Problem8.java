public class Problem8 {
	public static void main(String[] args) {
		int i, j;
		i = 2;
		int k = 1;
		if (i == 2) {
			k = j;
		} else {
			j = k;
		}
	}
}

//the variables must be initialized i & j